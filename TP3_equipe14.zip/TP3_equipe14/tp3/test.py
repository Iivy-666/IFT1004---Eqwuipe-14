ma_liste = ['toto', 'allo', 'bonjour']
print('coucou' in ma_liste)
